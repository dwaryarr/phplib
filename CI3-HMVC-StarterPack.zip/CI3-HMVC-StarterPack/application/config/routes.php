<?php
defined('BASEPATH') or exit('No direct script access allowed');

$route['default_controller'] = 'welcome';
$route['translate_uri_dashes'] = FALSE;
// Error Page
$route['404_override'] = '';
// $route['unauthorized-401'] = 'home/error401';
// $route['contohroute'] = 'contoh/route';
// $route['contoh-route/(:any)'] = 'contoh/route/$1';